jQuery(document).ready(function($){
								
/* ------------------------------------------------------------------ */
/* Sticky header
/* ------------------------------------------------------------------ */
$(window).load(function(){
	var ele = $('#header-container.has_sticky');
	var header_height = ele.height();
	if (matchMedia('only screen and (min-width: 768px)').matches && $('body').hasClass('responsive')) {
		ele.parent().css({height:header_height + 'px'});

		$(window).on('scroll',function(){									   
			var from_top = $(this).scrollTop();
			var adminbar_height = $('#wpadminbar').height();
			
			if ( from_top >= (adminbar_height + header_height + 100)) {
				ele.addClass('is-sticky');
			} else {
				ele.removeClass('is-sticky');	
			}
		}); // on scroll
		
						} // matchMedia min width 768px
						
	$(window).on('resize',function(){									   
		if (matchMedia('only screen and (max-width: 767px)').matches) {
			ele.parent().css({height:'auto'});
		}
	}); // on resize
				
}); // on load				
/* ------------------------------------------------------------------ */
/* Nav
/* ------------------------------------------------------------------ */
$('#mainnav .menu > ul > li').has('ul').addClass('has-child');

/* ------------------------------------------------------------------ */
/* Responsive Nav
/* ------------------------------------------------------------------ */
$('.nav-toggle').on('click',function(){
	$('#mainnav .menu > ul').slideToggle('fast');
	return false;
									 });

/* ------------------------------------------------------------------ */
/* Fitvids
/* ------------------------------------------------------------------ */
if ( $().fitVids ) {
	$('.media-container').fitVids();
}

/* ------------------------------------------------------------------ */
/* Autosize
/* ------------------------------------------------------------------ */
if ( $().autosize )	{
	$('textarea').autosize();
}
/* ------------------------------------------------------------------ */
/* Sidr
/* ------------------------------------------------------------------ */

if ( $().sidr ) {
	
		$('#sidr-toggle').sidr({
			side: 'right'
								});
}	// if sidr

$(window).load(function(){
						
if ( $().mCustomScrollbar ) {
	
		custom = $("#sidr").mCustomScrollbar({
			mouseWheel:true,
			scrollButtons:{
				  enable:true,
				  scrollType: 'continuous',
				},
			autoHideScrollbar: true,
			scrollInertia:300,
			advanced:{
				updateOnContentResize:true
			}
									 });	// scrollbar
							
}	// if mCustomScrollbar

});	// window load

/* ------------------------------------------------------------------ */
/* flexslider
/* ------------------------------------------------------------------ */
$(window).load(function(){

if ( $().flexslider ) {

	$('.thumb .flexslider').each(function(){
		var $this = $(this);		
		$this.flexslider({
		animation		:	$this.data('effect'),
		pauseOnHover	:	true,
		useCSS			:	false,
		easing			:	'easeInOutExpo',
		animationSpeed	:	850,
		controlNav		:	false,
		directionNav	:	$this.data('navi'),
		slideshow		:	$this.data('auto'),
		smoothHeight	:	$this.data('smooth-height'),
							 });	// flexslider
									});	// each
}	// endif 

});	// window load

/* ------------------------------------------------------------------ */
/* Colorbox
/* ------------------------------------------------------------------ */
if ( $().colorbox ) {
	$('.wi-colorbox').colorbox({
		transition	:	'none',
		speed		:	100,
		maxWidth	:	'90%',
		maxHeight	:	'90%',
							  });
	$('.gallery').each(function(index){
		var id = (	$(this).attr('id')	) ? $(this).attr('id') : 'gallery-' + index;
		$(this).
		find('.gallery-item').
		find('a[href$=".gif"], a[href$=".jpg"], a[href$=".png"], a[href$=".bmp"]').
		has('img').
		colorbox({
			transition	:	'none',
			speed		:	100,
			maxWidth	:	'90%',
			maxHeight	:	'90%',
			rel			:	id,
							  });
								});	// each
	}	// colorbox
/* ------------------------------------------------------------------ */
/* Tipsy
/* ------------------------------------------------------------------ */
if ( $().tipsy )	{
	$('.hastip').tipsy({
		fade	:	true,
		gravity	: 	's',
		opacity	:	'.9',
					   });
	
	$('#header .social li a').tipsy({
		fade	:	true,
		gravity	: 	'n',
		opacity	:	'.9',
					   });
	
}
/* --------------------------------------------------------------------------------------------- */
/* Gmap
/* --------------------------------------------------------------------------------------------- */
function wi_showmap() {
$('.wi-gmap').each(function(){
	var $this = $(this);
	var id = $this.attr('id');
	var map = new GMaps({
		div: '#' + id,
		lat: $this.data('lat'),
		lng: $this.data('lng'),
		zoom:$this.data('zoom'),		
	});

	if ( $this.data('marker') == true ) {
		var args = {
			lat: $this.data('lat'),
			lng: $this.data('lng'),
			title: $this.data('address'),
		}
		if ( $this.data('info') ) args['infoWindow'] = { content: '<div class="gmap-info">' + $this.data('info') + '</div>' };

		var marker = map.addMarker(args);	// add marker
		if ($this.data('open_info') == true) {
			setTimeout(function(){google.maps.event.trigger(marker, 'click')},500);
		}
		
	}	// if marker
						 });	// each
}	// wi showmap

$(window).load(wi_showmap);

/* --------------------------------------------------------------------------------------------- */
/* Progress
/* --------------------------------------------------------------------------------------------- */		
if ( $().easyPieChart )	{
	$('.wi-progress').each(function(){
		var $this = $(this);			
		$this.waypoint(function(){
			$this.parent().animate({opacity:1});
			$this.easyPieChart({
				'trackColor':	'#ddd',
				'barColor'	:	$this.data('color'),
				'scaleColor':	false,
				'lineCap'	:	'butt',
				'lineWidth'	:	$this.data('thickness'),
				'size'		:	$this.data('size'),
				'animate'	:	1200,
				onStep		:	function(value) {
									this.$el.find('span').text(~~value);
								},
				onStop		:	function() {
									var percent = this.$el.data('percent');
									this.$el.find('span').text(percent);
								}				
			});	// peeChart
								 }, {offset:'90%'});	// wayponit
		
							 });	// each
}	// if
/* --------------------------------------------------------------------------------------------- */
/* ScrollTop
/* --------------------------------------------------------------------------------------------- */
$(window).scroll(function(){
	if ($(this).scrollTop() > 200) {
		$('.scrollup').fadeIn();
	} else {
		$('.scrollup').fadeOut();
	}
}); 

$('.scrollup').click(function(){
	$("html, body").animate({ scrollTop: 0 }, 1000 , 'easeInOutExpo');
	return false;
});

/* --------------------------------------------------------------------------------------------- */
/* Wrap Sidebar Widget List
/* --------------------------------------------------------------------------------------------- */
$('.widget_archive ul > li, .widget_categories ul > li, .widget_recent_entries ul > li').each (function() {
	var clone = $(this).clone();
	clone.find('>a').remove();
	if ( $.trim(clone.html())!= '' ) {
		$(this).addClass('has-count');
	}	else {
		$(this).addClass('doesnt-have-count');
	}
								  });
$('.widget ul li.has-count a').wrap('<span class="widget-link-container" />');

/* --------------------------------------------------------------------------------------------- */
/* Pagination Next / Prev
/* --------------------------------------------------------------------------------------------- */
$('.wi-pagination').find('li').has('.prev').addClass('li-navi');
$('.wi-pagination').find('li').has('.next').addClass('li-navi');						   
						   
/* --------------------------------------------------------------------------------------------- */
/* Social Share
/* --------------------------------------------------------------------------------------------- */
var Config = {
	Link: ".social-share a",
	Width: 500,
	Height: 500
};

$(Config.Link).click(function(e){

	e = (e ? e : window.event);
	var t = $(this);

	// popup position
	var
		px = Math.floor(((screen.availWidth || 1024) - Config.Width) / 2),
		py = Math.floor(((screen.availHeight || 700) - Config.Height) / 2);

	// open popup
	if(t.data('href')) {
		var popup = window.open(t.attr('data-href'), "social", 
			"width="+Config.Width+",height="+Config.Height+
			",left="+px+",top="+py+
			",location=0,menubar=0,toolbar=0,status=0,scrollbars=1,resizable=1");
		if (popup) {
			popup.focus();
			if (e.preventDefault) e.preventDefault();
			e.returnValue = false;
		}
 
		return !!popup;
	}
}); // click					   
						   
						   
						   });	// jquery

