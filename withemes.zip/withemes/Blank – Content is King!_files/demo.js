jQuery(document).ready(function($){
	if ( typeof(demo_style)!= 'undefined' && demo_style ) {
		$('a').each(function(){
			var $this = $(this);
			var href = $this.attr('href');
			var hash, qr;
			if (href) hash = href.split('#')[1];
			if (href) qr = href.split('?')[1];
			if (!hash) {				
				if ( !qr ) $this.attr('href',href + '?demo='+demo_style);
				if ( qr ) {
					if ( qr.substr(0,4) == 'demo' ) {
					} else {
						$this.attr('href',href + '&demo='+demo_style);
					}
				}
			} else {
				$this.attr('href',href.replace('#','?demo='+demo_style +'#') );
				}
							 }); // each a
		}
								
				}); // jquery